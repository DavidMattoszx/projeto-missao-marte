[![Pipeline Missao Marte](https://github.com/DavidMattoszx/projeto-missao-marte/actions/workflows/pipeline.yml/badge.svg)](https://github.com/DavidMattoszx/projeto-missao-marte/actions/workflows/pipeline.yml)

# Missao Marte: ECLSS - Automacao de Testes Integrada

Suite de testes do sistema de suporte a vida do Habitat de Marte:

- **pytest**: fixtures (`conftest.py`, escopo session/function, `yield`), `parametrize`, `pytest.raises`
- **pytest-mock**: isolamento do `ServicoTelemetriaEspacial` (`mocker.patch`, `assert_called_once_with`)
- **Selenium WebDriver** headless com esperas explicitas e screenshot automatico em falhas (`evidencias/`)
- **pytest-bdd**: cenarios Gherkin em `tests/features/`
- **GitHub Actions**: `.github/workflows/pipeline.yml` com relatorio `pytest-cov`

## Executando localmente

Requisitos: Python 3.10+ e Google Chrome instalado (para os testes Selenium).

```bash
git clone https://github.com/DavidMattoszx/projeto-missao-marte.git
cd projeto-missao-marte
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
pytest
```

Com cobertura: `pytest --cov=src --cov-report=term-missing`

## Estrutura

```
src/        regra de negocio e servico de telemetria
tests/      unitarios, mocks, Selenium E2E e BDD
web/        painel.html
```
