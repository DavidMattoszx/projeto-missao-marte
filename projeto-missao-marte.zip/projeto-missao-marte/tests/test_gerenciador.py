import json

import pytest

from src.gerenciador_recursos import (
    AguaInsuficienteError,
    CotaExcedidaError,
    GerenciadorRecursosMarte,
    NivelEmergenciaInvalidoError,
    OxigenioInsuficienteError,
)
from src.servico_telemetria import ServicoTelemetriaEspacial


# ---------- Parametrizacao ----------
@pytest.mark.parametrize(
    "astronautas, taxa, esperado",
    [
        (4, 0.0, 3.36),
        (4, 0.5, 5.04),
        (6, 0.0, 5.04),
        (1, 1.0, 1.68),
        (10, 0.25, 10.5),
    ],
)
def test_consumo_diario_oxigenio(gerenciador, astronautas, taxa, esperado):
    assert gerenciador.consumo_diario_oxigenio(astronautas, taxa) == pytest.approx(esperado)


@pytest.mark.parametrize("astronautas, esperado", [(1, 3.0), (4, 12.0), (7, 21.0)])
def test_consumo_diario_agua(gerenciador, astronautas, esperado):
    assert gerenciador.consumo_diario_agua(astronautas) == pytest.approx(esperado)


# ---------- Excecoes ----------
@pytest.mark.parametrize("taxa", [-0.1, 1.01, 2, -5])
def test_taxa_emergencia_invalida(gerenciador, taxa):
    with pytest.raises(NivelEmergenciaInvalidoError):
        gerenciador.consumo_diario_oxigenio(taxa_emergencia=taxa)


@pytest.mark.parametrize("astronautas", [0, -3])
def test_numero_astronautas_invalido(gerenciador, astronautas):
    with pytest.raises(ValueError):
        gerenciador.consumo_diario_oxigenio(astronautas)
    with pytest.raises(ValueError):
        gerenciador.consumo_diario_agua(astronautas)


def test_construtor_rejeita_zero_astronautas(telemetria_mock):
    with pytest.raises(ValueError):
        GerenciadorRecursosMarte(telemetria_mock, 100, 100, 0)


def test_validar_estoque_ok(gerenciador):
    assert gerenciador.validar_estoque(dias=100) is True


def test_validar_estoque_oxigenio_insuficiente(gerenciador):
    with pytest.raises(OxigenioInsuficienteError, match="Necessario"):
        gerenciador.validar_estoque(dias=200)


def test_validar_estoque_agua_insuficiente(gerenciador):
    gerenciador.oxigenio = 10_000.0
    with pytest.raises(AguaInsuficienteError):
        gerenciador.validar_estoque(dias=101)


def test_dias_de_autonomia(gerenciador):
    assert gerenciador.dias_de_autonomia() == 148


@pytest.mark.parametrize("dias, esperado", [(200, 0.625), (100, 0.84), (50, 0.84)])
def test_racionamento(gerenciador, dias, esperado):
    assert gerenciador.aplicar_racionamento(dias) == pytest.approx(esperado)


def test_racionamento_dias_invalidos(gerenciador):
    with pytest.raises(ValueError):
        gerenciador.aplicar_racionamento(0)


# ---------- Mocks: solicitacao de oxigenio extra ----------
def test_solicitacao_normal_envia_relatorio(gerenciador, telemetria_mock):
    resultado = gerenciador.solicitar_oxigenio_extra(20)

    assert resultado["aprovado"] is True
    assert resultado["oxigenio_restante"] == 480.0
    assert resultado["confirmacao_terra"] == {"status": "recebido"}
    telemetria_mock.enviar_relatorio.assert_called_once_with(
        {"oxigenio": 480.0, "agua": 1200.0}
    )
    telemetria_mock.enviar_alerta.assert_not_called()


def test_solicitacao_em_crise_dispara_alerta(gerenciador, telemetria_mock):
    gerenciador.oxigenio = 60.0

    resultado = gerenciador.solicitar_oxigenio_extra(15)

    telemetria_mock.enviar_alerta.assert_called_once_with(
        "CRITICO", "Oxigenio abaixo do limite critico: 45.0 unidades"
    )
    telemetria_mock.enviar_relatorio.assert_not_called()
    assert resultado["confirmacao_terra"] == {"status": "alerta_recebido"}


def test_solicitacao_acima_da_cota_nao_chama_telemetria(gerenciador, telemetria_mock):
    with pytest.raises(CotaExcedidaError):
        gerenciador.solicitar_oxigenio_extra(25)
    telemetria_mock.enviar_relatorio.assert_not_called()
    telemetria_mock.enviar_alerta.assert_not_called()
    assert gerenciador.oxigenio == 500.0


def test_solicitacao_sem_estoque(gerenciador):
    gerenciador.oxigenio = 10.0
    with pytest.raises(OxigenioInsuficienteError):
        gerenciador.solicitar_oxigenio_extra(15)


@pytest.mark.parametrize("quantidade", [0, -5])
def test_solicitacao_quantidade_invalida(gerenciador, quantidade):
    with pytest.raises(ValueError):
        gerenciador.solicitar_oxigenio_extra(quantidade)


def test_mocker_patch_em_metodo_da_classe(mocker, parametros_habitat):
    """Usa mocker.patch.object para simular a resposta da estacao terrestre."""
    patch = mocker.patch.object(
        ServicoTelemetriaEspacial, "enviar_relatorio", return_value={"status": "ok-terra"}
    )
    g = GerenciadorRecursosMarte(ServicoTelemetriaEspacial(), **parametros_habitat)

    resultado = g.solicitar_oxigenio_extra(10)

    assert resultado["confirmacao_terra"] == {"status": "ok-terra"}
    patch.assert_called_once_with({"oxigenio": 490.0, "agua": 1200.0})


# ---------- Servico de telemetria sem rede ----------
def test_servico_enviar_alerta_monta_payload(mocker):
    post = mocker.patch.object(ServicoTelemetriaEspacial, "_post", return_value={"ok": 1})
    resposta = ServicoTelemetriaEspacial().enviar_alerta("CRITICO", "teste")
    post.assert_called_once_with("/alertas", {"nivel": "CRITICO", "mensagem": "teste"})
    assert resposta == {"ok": 1}


def test_servico_enviar_relatorio_monta_payload(mocker):
    post = mocker.patch.object(ServicoTelemetriaEspacial, "_post", return_value={})
    ServicoTelemetriaEspacial().enviar_relatorio({"oxigenio": 1})
    post.assert_called_once_with("/relatorios", {"oxigenio": 1})


def test_servico_post_isola_rede(mocker):
    resposta = mocker.MagicMock()
    resposta.read.return_value = json.dumps({"status": "recebido"}).encode()
    resposta.__enter__.return_value = resposta
    urlopen = mocker.patch(
        "src.servico_telemetria.urllib.request.urlopen", return_value=resposta
    )

    assert ServicoTelemetriaEspacial()._post("/x", {"a": 1}) == {"status": "recebido"}
    urlopen.assert_called_once()
