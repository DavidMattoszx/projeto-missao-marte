from pathlib import Path

import pytest

from src.gerenciador_recursos import GerenciadorRecursosMarte
from src.servico_telemetria import ServicoTelemetriaEspacial

RAIZ = Path(__file__).resolve().parent.parent
EVIDENCIAS = RAIZ / "evidencias"


@pytest.fixture(scope="session")
def parametros_habitat():
    """Parametros iniciais do habitat (carregados uma unica vez por sessao)."""
    return {"oxigenio": 500.0, "agua": 1200.0, "astronautas": 4}


@pytest.fixture
def telemetria_mock(mocker):
    """Dubla o servico de telemetria: nenhuma chamada de rede e feita."""
    mock = mocker.Mock(spec=ServicoTelemetriaEspacial)
    mock.enviar_relatorio.return_value = {"status": "recebido"}
    mock.enviar_alerta.return_value = {"status": "alerta_recebido"}
    return mock


@pytest.fixture
def gerenciador(parametros_habitat, telemetria_mock):
    """Instancia limpa por teste, com preparacao e limpeza via yield."""
    g = GerenciadorRecursosMarte(telemetria_mock, **parametros_habitat)
    yield g
    # limpeza: invariante de seguranca e reset do dubla
    assert g.oxigenio >= 0 and g.agua >= 0
    telemetria_mock.reset_mock()


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    """Guarda o resultado de cada fase para a fixture do driver consultar."""
    outcome = yield
    setattr(item, "rep_" + call.when, outcome.get_result())


@pytest.fixture
def driver(request):
    """WebDriver headless; tira screenshot automatico em caso de falha."""
    from selenium import webdriver
    from selenium.webdriver.chrome.options import Options

    opcoes = Options()
    opcoes.add_argument("--headless=new")
    opcoes.add_argument("--no-sandbox")
    opcoes.add_argument("--disable-dev-shm-usage")
    opcoes.add_argument("--window-size=1280,900")
    drv = webdriver.Chrome(options=opcoes)
    try:
        yield drv
    finally:
        rep = getattr(request.node, "rep_call", None)
        if rep is not None and rep.failed:
            EVIDENCIAS.mkdir(exist_ok=True)
            nome = "".join(c if c.isalnum() else "_" for c in request.node.name)
            drv.save_screenshot(str(EVIDENCIAS / f"{nome}.png"))
        drv.quit()
