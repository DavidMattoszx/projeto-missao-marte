import pytest
from pytest_bdd import given, parsers, scenarios, then, when

from src.gerenciador_recursos import CotaExcedidaError, GerenciadorRecursosMarte

scenarios("features/solicitacao_oxigenio.feature")


@pytest.fixture
def contexto():
    return {}


@given(
    parsers.parse("um habitat com {oxigenio:d} unidades de oxigenio e {astronautas:d} astronautas"),
    target_fixture="habitat",
)
def habitat(oxigenio, astronautas, telemetria_mock):
    return GerenciadorRecursosMarte(telemetria_mock, oxigenio, 1200, astronautas)


@when(parsers.parse("o astronauta solicita {quantidade:d} unidades de oxigenio extra"))
def solicitar(habitat, quantidade, contexto):
    try:
        contexto["resultado"] = habitat.solicitar_oxigenio_extra(quantidade)
    except CotaExcedidaError as erro:
        contexto["erro"] = erro


@then("a solicitacao e aprovada")
def aprovada(contexto):
    assert contexto["resultado"]["aprovado"] is True


@then(parsers.parse("restam {restante:d} unidades de oxigenio"))
def restante(habitat, restante):
    assert habitat.oxigenio == restante


@then("um relatorio de status e enviado para a Terra")
def relatorio_enviado(telemetria_mock):
    telemetria_mock.enviar_relatorio.assert_called_once()
    telemetria_mock.enviar_alerta.assert_not_called()


@then("um alerta de emergencia e enviado para a Terra")
def alerta_enviado(telemetria_mock):
    telemetria_mock.enviar_alerta.assert_called_once_with(
        "CRITICO", "Oxigenio abaixo do limite critico: 45.0 unidades"
    )


@then("a solicitacao e negada por cota excedida")
def negada(contexto):
    assert isinstance(contexto.get("erro"), CotaExcedidaError)


@then("nenhuma mensagem e enviada para a Terra")
def nada_enviado(telemetria_mock):
    telemetria_mock.enviar_relatorio.assert_not_called()
    telemetria_mock.enviar_alerta.assert_not_called()
