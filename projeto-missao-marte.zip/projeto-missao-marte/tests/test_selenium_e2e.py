from pathlib import Path

from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

PAINEL = (Path(__file__).resolve().parent.parent / "web" / "painel.html").as_uri()


def _solicitar(driver, nome, quantidade):
    driver.find_element(By.ID, "astronauta").send_keys(nome)
    driver.find_element(By.ID, "quantidade").send_keys(str(quantidade))
    driver.find_element(By.ID, "btn-solicitar").click()


def test_solicitacao_oxigenio_atualiza_nivel(driver):
    driver.get(PAINEL)
    espera = WebDriverWait(driver, 10)
    assert driver.find_element(By.ID, "nivel-oxigenio").text == "500.0"

    _solicitar(driver, "Ripley", 20)

    espera.until(EC.text_to_be_present_in_element((By.ID, "nivel-oxigenio"), "480.0"))
    espera.until(EC.text_to_be_present_in_element((By.ID, "mensagem-status"), "aprovada"))
    assert "Ripley" in driver.find_element(By.ID, "mensagem-status").text


def test_solicitacao_acima_da_cota_e_negada(driver):
    driver.get(PAINEL)
    espera = WebDriverWait(driver, 10)

    _solicitar(driver, "Watney", 50)

    espera.until(EC.text_to_be_present_in_element((By.ID, "mensagem-status"), "Cota maxima"))
    assert driver.find_element(By.ID, "nivel-oxigenio").text == "500.0"


def test_formulario_vazio_mostra_erro(driver):
    driver.get(PAINEL)
    driver.find_element(By.ID, "btn-solicitar").click()
    WebDriverWait(driver, 10).until(
        EC.text_to_be_present_in_element((By.ID, "mensagem-status"), "invalidos")
    )
