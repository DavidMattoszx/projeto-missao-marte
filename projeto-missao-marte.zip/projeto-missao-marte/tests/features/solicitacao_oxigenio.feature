# language: pt
Funcionalidade: Solicitacao de suprimentos de oxigenio
  Como astronauta do habitat de Marte
  Quero solicitar oxigenio extra
  Para manter a seguranca da tripulacao

  Cenario: Solicitacao em condicoes normais
    Dado um habitat com 500 unidades de oxigenio e 4 astronautas
    Quando o astronauta solicita 20 unidades de oxigenio extra
    Entao a solicitacao e aprovada
    E restam 480 unidades de oxigenio
    E um relatorio de status e enviado para a Terra

  Cenario: Solicitacao que leva o habitat a uma situacao de crise
    Dado um habitat com 60 unidades de oxigenio e 4 astronautas
    Quando o astronauta solicita 15 unidades de oxigenio extra
    Entao a solicitacao e aprovada
    E restam 45 unidades de oxigenio
    E um alerta de emergencia e enviado para a Terra

  Cenario: Solicitacao acima da cota maxima
    Dado um habitat com 500 unidades de oxigenio e 4 astronautas
    Quando o astronauta solicita 25 unidades de oxigenio extra
    Entao a solicitacao e negada por cota excedida
    E nenhuma mensagem e enviada para a Terra
