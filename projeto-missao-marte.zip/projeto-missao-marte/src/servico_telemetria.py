"""Servico de telemetria: comunicacao externa com a estacao na Terra."""
import json
import urllib.request


class ServicoTelemetriaEspacial:
    """Envia relatorios e alertas para a estacao terrestre (dependencia externa)."""

    def __init__(self, url_base="https://estacao-terra.example/api", timeout=5.0):
        self.url_base = url_base
        self.timeout = timeout

    def _post(self, endpoint, payload):
        dados = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            self.url_base + endpoint,
            data=dados,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=self.timeout) as resposta:
            return json.loads(resposta.read().decode("utf-8"))

    def enviar_relatorio(self, dados):
        return self._post("/relatorios", dados)

    def enviar_alerta(self, nivel, mensagem):
        return self._post("/alertas", {"nivel": nivel, "mensagem": mensagem})
