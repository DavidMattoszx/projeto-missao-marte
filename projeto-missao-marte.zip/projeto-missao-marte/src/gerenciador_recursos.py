"""Regra de negocio do ECLSS (Environmental Control and Life Support System)."""
import math


class OxigenioInsuficienteError(Exception):
    """Estoque de oxigenio insuficiente para a operacao."""


class AguaInsuficienteError(Exception):
    """Estoque de agua insuficiente para a operacao."""


class NivelEmergenciaInvalidoError(Exception):
    """Taxa de emergencia fora do intervalo permitido [0.0, 1.0]."""


class CotaExcedidaError(Exception):
    """Solicitacao acima da cota maxima de oxigenio extra."""


class GerenciadorRecursosMarte:
    CONSUMO_O2_ASTRONAUTA_DIA = 0.84   # kg
    CONSUMO_AGUA_ASTRONAUTA_DIA = 3.0  # litros
    LIMITE_CRITICO_O2 = 50.0
    COTA_EXTRA_MAXIMA = 20.0

    def __init__(self, telemetria, oxigenio, agua, astronautas):
        if astronautas <= 0:
            raise ValueError("O numero de astronautas deve ser positivo")
        self.telemetria = telemetria
        self.oxigenio = float(oxigenio)
        self.agua = float(agua)
        self.astronautas = astronautas

    @staticmethod
    def _validar_taxa(taxa_emergencia):
        if not 0.0 <= taxa_emergencia <= 1.0:
            raise NivelEmergenciaInvalidoError(
                f"Taxa de emergencia invalida: {taxa_emergencia}"
            )

    def consumo_diario_oxigenio(self, astronautas=None, taxa_emergencia=0.0):
        astronautas = self.astronautas if astronautas is None else astronautas
        if astronautas <= 0:
            raise ValueError("O numero de astronautas deve ser positivo")
        self._validar_taxa(taxa_emergencia)
        return round(
            astronautas * self.CONSUMO_O2_ASTRONAUTA_DIA * (1 + taxa_emergencia), 2
        )

    def consumo_diario_agua(self, astronautas=None):
        astronautas = self.astronautas if astronautas is None else astronautas
        if astronautas <= 0:
            raise ValueError("O numero de astronautas deve ser positivo")
        return round(astronautas * self.CONSUMO_AGUA_ASTRONAUTA_DIA, 2)

    def validar_estoque(self, dias, taxa_emergencia=0.0):
        necessario_o2 = self.consumo_diario_oxigenio(taxa_emergencia=taxa_emergencia) * dias
        if necessario_o2 > self.oxigenio:
            raise OxigenioInsuficienteError(
                f"Necessario {necessario_o2:.2f}, disponivel {self.oxigenio:.2f}"
            )
        necessario_agua = self.consumo_diario_agua() * dias
        if necessario_agua > self.agua:
            raise AguaInsuficienteError(
                f"Necessario {necessario_agua:.2f}, disponivel {self.agua:.2f}"
            )
        return True

    def dias_de_autonomia(self, taxa_emergencia=0.0):
        consumo = self.consumo_diario_oxigenio(taxa_emergencia=taxa_emergencia)
        return math.floor(self.oxigenio / consumo)

    def aplicar_racionamento(self, dias_alvo):
        """Cota diaria de O2 por astronauta para o estoque durar `dias_alvo`."""
        if dias_alvo <= 0:
            raise ValueError("dias_alvo deve ser positivo")
        cota = self.oxigenio / (self.astronautas * dias_alvo)
        return round(min(cota, self.CONSUMO_O2_ASTRONAUTA_DIA), 3)

    def solicitar_oxigenio_extra(self, quantidade):
        if quantidade <= 0:
            raise ValueError("A quantidade deve ser positiva")
        if quantidade > self.COTA_EXTRA_MAXIMA:
            raise CotaExcedidaError(
                f"Cota maxima de {self.COTA_EXTRA_MAXIMA} unidades excedida"
            )
        if quantidade > self.oxigenio:
            raise OxigenioInsuficienteError("Estoque insuficiente para a solicitacao")

        self.oxigenio -= quantidade
        resultado = {"aprovado": True, "oxigenio_restante": self.oxigenio}

        if self.oxigenio < self.LIMITE_CRITICO_O2:
            resultado["confirmacao_terra"] = self.telemetria.enviar_alerta(
                "CRITICO",
                f"Oxigenio abaixo do limite critico: {self.oxigenio:.1f} unidades",
            )
        else:
            resultado["confirmacao_terra"] = self.telemetria.enviar_relatorio(
                {"oxigenio": self.oxigenio, "agua": self.agua}
            )
        return resultado
